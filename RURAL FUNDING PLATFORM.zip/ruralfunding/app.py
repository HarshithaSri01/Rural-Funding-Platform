from flask import Flask, render_template, redirect, url_for, request, session, flash
from flask_pymongo import PyMongo
from bson.objectid import ObjectId
import os
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['MONGO_URI'] = "mongodb://localhost:27017/ruralfunding"
app.secret_key = 'your_secret_key'
app.config['UPLOAD_FOLDER'] = 'static/uploads'  # Folder to store uploaded images
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif'}

mongo = PyMongo(app)

# Helper function to check allowed file types
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# Routes
@app.route('/')
def home():
    issues = mongo.db.issues.find()
    return render_template('home.html', issues=issues)

@app.route('/contact')
def contact():
    return render_template('contact.html')


@app.route('/submit_contact', methods=['POST'])
def submit_contact():
    if request.method == 'POST':
        # Get form data
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')

        # Create a dictionary to store the contact form data
        contact_data = {
            'name': name,
            'email': email,
            'subject': subject,
            'message': message
        }

        # Insert the data into MongoDB (collection: contacts)
        mongo.db.contacts.insert_one(contact_data)

        # Flash a success message
        flash('Your message has been submitted successfully. We will get back to you soon!', 'success')

        # Redirect back to the contact page or any other page
        return redirect(url_for('contact'))

@app.route('/services')
def services():
    return render_template('services.html')

@app.route('/privacy_policies')
def privacy_policies():
    return render_template('privacy_policies.html')

# Registration Page
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        role = request.form.get('role')
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')

        # Check if an admin already exists
        if role == "admin":
            existing_admin = mongo.db.admins.find_one({'role': 'admin'})
            if existing_admin:
                flash('An admin account already exists. Only one admin is allowed.', 'danger')
                # Render the registration page again without redirecting
                return render_template('register.html')

        # Hash the password before storing it
        # hashed_password = generate_password_hash(password, method='sha256')

        # Insert the user data into the appropriate collection
        if role == "user":
            mongo.db.users.insert_one({'role': role, 'name': name, 'email': email, 'password': password})
        else:
            mongo.db.admins.insert_one({'role': role, 'name': name, 'email': email, 'password': password})

        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

# Login Page
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        role = request.form.get('role')
        email = request.form.get('email')
        password = request.form.get('password')

        # Check the role and authenticate the user/admin
        if role == "user":
            user = mongo.db.users.find_one({"email": email})
            if user :
                session['role'] = 'user'
                session['user_id'] = str(user['_id'])
                flash('Login successful!', 'success')
                return redirect(url_for('user_dashboard'))
            else:
                flash('Invalid credentials. Please try again.', 'danger')
                return redirect(url_for('login'))
        elif role == "admin":
            admin = mongo.db.admins.find_one({"email": email})
            if admin :
                session['role'] = 'admin'
                session['user_id'] = str(admin['_id'])
                flash('Login successful!', 'success')
                return redirect(url_for('admin_dashboard'))
            else:
                flash('Invalid credentials. Please try again.', 'danger')
                return redirect(url_for('login'))
        else:
            flash('Invalid role selected.', 'danger')
            return redirect(url_for('login'))

    return render_template('login.html')

# Admin Dashboard - Problem Posting and Managing
@app.route('/admin_dashboard', methods=['GET', 'POST'])
def admin_dashboard():
    if session.get('role') != 'admin':
        flash('Unauthorized access. Please log in as an admin.', 'danger')
        return redirect(url_for('login'))

    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part', 'danger')
            return redirect(request.url)

        file = request.files['file']
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
        
        file = request.files['qrcode']
        if file and allowed_file(file.filename):
            filename1 = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename1)
            file.save(file_path)

            problem_data = {
                'image': filename,
                'description': request.form.get('description'),
                'place_address': request.form.get('place_address'),
                'need_amount': request.form.get('need_amount'),
                'name': request.form.get('name'),
                'email': request.form.get('email'),
                'contact': request.form.get('contact'),
                'account': request.form.get('account'),
                'qrcode': filename1
            }
            mongo.db.issues.insert_one(problem_data)
            flash('Problem posted successfully!', 'success')
    donations=mongo.db.donations.find()
    issues = mongo.db.issues.find()
    return render_template('admin_dashboard.html', issues=issues, donations=donations)

# Edit Issue
@app.route('/edit_issue/<issue_id>', methods=['GET', 'POST'])
def edit_issue(issue_id):
    if session.get('role') != 'admin':
        flash('Unauthorized access. Please log in as an admin.', 'danger')
        return redirect(url_for('login'))

    issue = mongo.db.issues.find_one({'_id': ObjectId(issue_id)})

    if request.method == 'POST':
        updated_data = {
            'description': request.form.get('description'),
            'place_address': request.form.get('place_address'),
            'need_amount': request.form.get('need_amount'),
            'name': request.form.get('name'),
            'email': request.form.get('email'),
            'contact': request.form.get('contact'),
            'account': request.form.get('account')
        }

        if 'file' in request.files:
            file = request.files['file']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)
                updated_data['image'] = filename
        if 'qrcode' in request.files:
            file = request.files['qrcode']
            if file and allowed_file(file.filename):
                filename1 = secure_filename(file.filename)
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename1)
                file.save(file_path)
                updated_data['qrcode'] = filename1

        mongo.db.issues.update_one({'_id': ObjectId(issue_id)}, {'$set': updated_data})
        flash('Issue updated successfully!', 'success')
        return redirect(url_for('admin_dashboard'))

    return render_template('edit_issue.html', issue=issue)

# Delete Issue
@app.route('/delete_issue/<issue_id>', methods=['GET','POST'])
def delete_issue(issue_id):
    if session.get('role') != 'admin':
        flash('Unauthorized access. Please log in as an admin.', 'danger')
        return redirect(url_for('login'))

    mongo.db.issues.delete_one({'_id': ObjectId(issue_id)})
    flash('Issue deleted successfully!', 'success')
    return redirect(url_for('admin_dashboard'))


# User Dashboard - View Issues and Respond
@app.route('/user_dashboard', methods=['GET'])
def user_dashboard():
    if session.get('role') != 'user':
        flash('Unauthorized access. Please log in as a user.', 'danger')
        return redirect(url_for('login'))

    issues = mongo.db.issues.find()
    return render_template('user_dashboard.html', issues=issues)

    

@app.route("/issue_details/<issue_id>", methods=['GET', 'POST'])
def issue_details(issue_id):
    # Fetch the issue using the issue_id
    issue = mongo.db.issues.find_one({"_id": ObjectId(issue_id)})

    if not issue:
        flash('Issue not found', 'danger')
        return redirect(url_for('user_dashboard'))

    # Render the issue details page, passing the issue and its comments to the template
    return render_template('issue_details.html', issue=issue)


    

# Route to donate to a specific issue
@app.route('/donate/<issue_id>', methods=['GET', 'POST'])
def donate_issue(issue_id):
    # Find the issue by ID
    issue = mongo.db.issues.find_one({"_id": ObjectId(issue_id)})

    if not issue:
        flash('Issue not found', 'danger')
        return redirect(url_for('user_dashboard'))

    if request.method == 'POST':
        # Extract donation form data
        donor_name = request.form['donor_name']
        contact = request.form['contact']
        address = str(request.form['address'])
        donate_amount = request.form['donate_amount']
        account = str(request.form['account'])
        payment_option = request.form['payment_option']
        
        # Handle file upload for payment proof
        payment_proof = request.files['payment_proof']
        if payment_proof and allowed_file(payment_proof.filename):
            filename = secure_filename(payment_proof.filename)
            payment_proof.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        else:
            flash('Invalid payment proof format. Please upload a valid file.', 'danger')
            return redirect(url_for('user_dashboard'))


        # Save donation data in MongoDB
        donation_data = {
            'donor_name': donor_name,
            'contact': contact,
            'issue_id': issue_id,
            'address': address,
            'donate_amount': donate_amount,
            'account': account,
            'payment_option': payment_option,
            'payment_proof': filename  # Save the filename of the uploaded payment proof
        }

        mongo.db.donations.insert_one(donation_data)
        flash('Thank you for your donation!', 'success')
        
        return redirect(url_for('user_dashboard'))

    return render_template('donate.html', issue=issue)


@app.route('/contact_submissions')
def contact_submissions():
    # Fetch all contact form submissions from the MongoDB collection
    contacts = mongo.db.contacts.find()
    
    return render_template('contact_submissions.html', contacts=contacts)


# Function to validate allowed file types for payment proof
def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
# Logout
@app.route('/logout')
def logout():
    session.clear()  # Clear the session
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
